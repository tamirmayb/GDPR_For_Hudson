package com.example.demo.component;

import com.example.demo.interfaces.ConsentStrategy;
import com.example.demo.model.User;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class StandardConsentStrategy implements ConsentStrategy {

    @Override
    public User processConsent(User user) {
        if(user.getConsentGiven()) {
            user.setConsentTimestamp(LocalDateTime.now());
        } else {
            throw new IllegalArgumentException("User consent is required");
        }
        return user;
    }
}
