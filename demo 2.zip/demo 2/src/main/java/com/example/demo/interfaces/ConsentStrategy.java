package com.example.demo.interfaces;

import com.example.demo.model.User;

public interface ConsentStrategy {
    User processConsent(User user);
}
