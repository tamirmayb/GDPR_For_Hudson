package com.example.demo.service;

import com.example.demo.component.AdminImpliedConsentStrategy;
import com.example.demo.component.StandardConsentStrategy;
import com.example.demo.interfaces.ConsentStrategy;
import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

@Service
public class UserService {
    private final Map<Role, ConsentStrategy> strategies;
    private final UserRepository userRepository;

    public UserService(StandardConsentStrategy standardConsentStrategy, AdminImpliedConsentStrategy adminImpliedConsentStrategy, UserRepository userRepository) {
        this.strategies = Map.of(
                Role.USER, standardConsentStrategy,
                Role.ADMIN, adminImpliedConsentStrategy
        );
        this.userRepository = userRepository;
    }

    public User createUser(User user) {
        user.setId(UUID.randomUUID());
        ConsentStrategy strategy = strategies.get(user.getRole());
        User userToSave = strategy.processConsent(user);
        return userRepository.save(userToSave);
    }
}
