package com.example.demo.model;

import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    private UUID id;
    private String email;
    private Role role;
    private Boolean consentGiven;
    private LocalDateTime consentTimestamp;
}
