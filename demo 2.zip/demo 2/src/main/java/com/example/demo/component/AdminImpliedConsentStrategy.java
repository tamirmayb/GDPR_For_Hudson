package com.example.demo.component;

import com.example.demo.interfaces.ConsentStrategy;
import com.example.demo.model.User;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class AdminImpliedConsentStrategy implements ConsentStrategy {

    @Override
    public User processConsent(User user) {
        user.setConsentGiven(true);
        user.setConsentTimestamp(LocalDateTime.now());
        return user;
    }
}
